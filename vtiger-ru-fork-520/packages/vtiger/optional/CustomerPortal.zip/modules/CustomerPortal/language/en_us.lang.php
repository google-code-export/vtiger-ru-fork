<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'CustomerPortal',
'LBL_BASIC_SETTINGS'=>'Basic Settings',
'LBL_ADVANCED_SETTINGS'=>'Advanced Settings',
'LBL_MODULE'=>'Module',
'LBL_VIEW_ALL_RECORD'=>'View All Related Records ?',
'YES'=>'Yes',
'NO'=>'No',
'LBL_USER_DESCRIPTION'=>'The above selected User\'s profile will be selected to control the fields that appear in the Customer Portal
				You can enable/disable the fields that show in the customer Portal.',
'SELECT_USERS'=>'Select the Users',				
'LBL_DISABLE'=>'Disable',
'LBL_ENABLE' =>'Enable',
'Module' => 'Module',
'Sequence' =>'Sequence',
'Visible'=>'Visible'

);

?>
